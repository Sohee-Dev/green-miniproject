package com.example.aquarium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AquariumApplicationTests {

	@Test
	void contextLoads() {
	}

}
