package com.example.aquarium.dto;

import lombok.Data;

@Data
public class TicketDTO {
	private String tno;
	private String tname;
	private int tprice;
	private String tcontent;
}
