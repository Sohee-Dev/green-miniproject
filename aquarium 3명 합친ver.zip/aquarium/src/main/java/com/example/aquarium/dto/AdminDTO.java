package com.example.aquarium.dto;

import lombok.Data;

@Data
public class AdminDTO {
	
	private String aid;
	private String apw;
	private String aname;
}
