package com.example.aquarium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AquariumApplication {

	public static void main(String[] args) {
		SpringApplication.run(AquariumApplication.class, args);
	}

}
