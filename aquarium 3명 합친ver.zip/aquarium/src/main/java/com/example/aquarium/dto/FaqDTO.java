package com.example.aquarium.dto;

import lombok.Data;

@Data
public class FaqDTO {

	private String fno;
	private String ftitle;
	private String fcontent;
}
