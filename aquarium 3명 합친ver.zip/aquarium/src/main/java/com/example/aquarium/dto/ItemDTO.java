package com.example.aquarium.dto;

import lombok.Data;

@Data
public class ItemDTO {
	private String ino;
	private String ono;
	private String tno;
	private int amount;
}
