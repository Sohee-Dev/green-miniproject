package com.example.aquarium.dto;

import lombok.Data;

@Data
public class MemberDto {
	private String id;
	private String pw;
	private String name;
	private String phone;
	private String birth;
	private String aim;
}
